---
name: kantljus-signatur
description: 'Lägg till Kantljus designersignatur när en webbplats byggs, designas om eller levereras åt användaren. Använd tillsammans med webbdesignskills, inklusive MJ Skill, så att varje sida får logga och länken Designat av: längst ner till höger i sidfoten.'
---

# Kantljus-signatur

Användarens standard för webbplatser vi designar är en diskret designersignatur med den bifogade Kantljus-loggan och den synliga texten **Designat av:**. Hela signaturen ska vara en vanlig klickbar länk till `https://kantljus.se/`.

## Utförande

- Lägg signaturen sist i den gemensamma sidfoten, högerställd, på varje sida inklusive undersidor och projektspecifika felsidor. Använd sidans normala dokumentflöde; den ska ligga längst ner på sidan, inte flyta ovanpå innehållet när man skrollar. Respektera ett uttryckligt önskemål om annan placering.
- Använd den framtagna konturloggan [assets/kantljus-outline.png](assets/kantljus-outline.png), 90 CSS-pixlar bred. Kopiera den till projektets publika bildmapp och använd en fungerande lokal asset-URL. Behåll bokstavsformerna och proportionerna; generera inte om loggan. [assets/kantljus-logo.png](assets/kantljus-logo.png) är originalet, sparat som referens.
- Utgå från [assets/signatur.html](assets/signatur.html) och [assets/signatur.css](assets/signatur.css), eller implementera motsvarande i projektets komponentramverk. Anpassa asset-sökvägen och importera CSS enligt projektets struktur.
- Behåll den exakta synliga texten och länkmålet. En enda länk omfattar både loggan och texten. Öppna i samma flik som standard. Inga klickhanterare, spårning eller externa bildanrop behövs.
- Signaturen ska vara liten men läsbar: textstorlek 11 px, logga 90 px och mellanrum 2 px. Text och logga ska kännas som en mening, utan en separat platta eller ram. Ingen animation eller stark uppmärksamhetseffekt.
- Konturloggan är en PNG med svart bakgrund, inte en transparent fil. Exempel-CSS använder `mix-blend-mode: screen` för att blanda bort svart på mörka sidfötter. För ljus sidfot, lägg klassen `kantljus-credit--light` på länken; den inverterar loggan och använder `multiply`. Anpassa textfärgen för kontrast. Kontrollera resultatet mot den faktiska bakgrunden.
- Behåll synlig tangentbordsfokus, minst 44 px klickhöjd och minst 4,5:1 textkontrast. Loggan ska ha alt-texten "Kantljus", så att länken läses som "Designat av: Kantljus" med skärmläsare. Tillåt radbrytning på smala skärmar utan att rubba högerställningen.
- Lägg in signaturen en gång per sida, gärna via gemensam footer eller layout. Bevara befintlig copyright, juridiska länkar och kundens varumärke. Om det redan finns exakt denna signatur, återanvänd den.

## Kontroll vid leverans

Linjeringen ska följa bokstävernas synliga baslinje: nederkanten på "Designat av:" ska ligga på samma nivå som loggans bokstäver, bortsett från nedstaplar som j. Centrering mot hela bildytan kan bli fel om loggan har tomma marginaler. Kontrollera optiskt i den faktiska visningsstorleken på mobil och desktop och justera textens vertikala placering vid behov.

Kontrollera att loggan laddas även på undersidor, att länken pekar till `https://kantljus.se/`, att signaturen finns en gång per sida och att den är högerställd och läsbar på mobil och desktop utan överlapp eller horisontell skroll. Kontrollera tangentbordsfokus.

Denna skill är en standard för webbplatser som designas, inte ett skäl att ändra alla historiska projekt vid en orelaterad uppgift. Användarens uttryckliga undantag gäller. Publicering följer den aktuella uppgiftens behörighet; installation av skillen publicerar inga webbplatsändringar.
